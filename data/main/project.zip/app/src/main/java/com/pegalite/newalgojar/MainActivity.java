package com.pegalite.newalgojar;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Window;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.pegalite.newalgojar.databinding.ActivityMainBinding;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    // Register the launcher early (as a field initializer)
    private final ActivityResultLauncher<Intent> unknownSourcesLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        // Check permission after returning from settings
                        if (getPackageManager().canRequestPackageInstalls()) {
                            installApk();
                        } else {
                            Toast.makeText(this, "Permission denied to install unknown apps", Toast.LENGTH_SHORT).show();
                        }
                    });
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        Window window = getWindow();
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.rich_blue));
        window.setNavigationBarColor(ContextCompat.getColor(this, R.color.rich_blue));

        binding.update.setOnClickListener(v -> {
            // For API 26 and above, check if the app can install packages from unknown sources
            if (!getPackageManager().canRequestPackageInstalls()) {
                // Request permission from the user to install apps from unknown sources
                Intent intent = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName()));
                unknownSourcesLauncher.launch(intent);
                return;
            }
            installApk();
        });
    }

    /**
     * Copies the APK from the raw resource folder to external storage and starts the installation process.
     */
    private void installApk() {
        // Define the destination file in the external files directory
        File apkFile = new File(getExternalFilesDir(null), "your_apk_file.apk");

        // Copy the APK from raw resource if it doesn't already exist
        if (!apkFile.exists()) {
            try (InputStream is = getResources().openRawResource(R.raw.app2);
                 FileOutputStream fos = new FileOutputStream(apkFile)) {
                byte[] buffer = new byte[1024];
                int length;
                while ((length = is.read(buffer)) > 0) {
                    fos.write(buffer, 0, length);
                }
                fos.flush();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to copy APK", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        // Create an intent to install the APK
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        // Use FileProvider for API 24+ to get a content:// URI
        Uri apkUri = FileProvider.getUriForFile(
                this,
                getApplicationContext().getPackageName() + ".provider",
                apkFile);
        intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        startActivity(intent);
    }
}
