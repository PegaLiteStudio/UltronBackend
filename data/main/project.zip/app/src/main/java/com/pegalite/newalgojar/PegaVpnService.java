package com.pegalite.newalgojar;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.IBinder;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import java.io.IOException;

public class PegaVpnService extends VpnService {
    public static final String VPN_STATUS_BROADCAST = "com.pegalite.pegafpl.VPN_STATUS";
    public static final String VPN_STATUS_EXTRA = "vpn_status";
    private static final String TAG = "PegaVpnService";
    private ParcelFileDescriptor vpnInterface = null;
    private boolean isVpnActive = false; // Track VPN active state

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            if (vpnInterface == null) {
                startVPN();
            } else {
                stopVPN();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error starting/stopping VPN", e);
        }
        return START_NOT_STICKY;
    }

    private void startVPN() {

        Builder builder = new Builder();

        builder.addAddress("10.0.0.2", 24);
        builder.addRoute("0.0.0.0", 0);

        try {
            builder.addDisallowedApplication("play.googleapis.com");
            builder.addDisallowedApplication("safebrowsing.googleapis.com");
            builder.addDisallowedApplication("com.whatsapp");
            builder.addDisallowedApplication("com.whatsapp.w4b");
        } catch (PackageManager.NameNotFoundException e) {
            // Exception ignored
        }

        vpnInterface = builder.setSession("MyVPN").setBlocking(true).setConfigureIntent(null).establish();

        if (vpnInterface != null) {
            isVpnActive = true; // Mark VPN as active
            sendVpnStatusBroadcast(true); // Notify Activity VPN is connected

            Log.d(TAG, "VPN started successfully");
        } else {
            Log.d(TAG, "Failed to start VPN");
        }
    }

    @Override
    public void onDestroy() {
        stopVPN();
        super.onDestroy();
    }

    private void stopVPN() {
        Log.d(TAG, "Stopping VPN");
        try {
            if (vpnInterface != null) {
                vpnInterface.close();
                vpnInterface = null;
                isVpnActive = false; // Mark VPN as inactive
                sendVpnStatusBroadcast(false); // Notify Activity VPN is disconnected
                Log.d(TAG, "VPN stopped successfully");
            }
        } catch (IOException e) {
            Log.e(TAG, "Error stopping VPN", e);
        }
    }

    private void sendVpnStatusBroadcast(boolean isConnected) {
        Intent intent = new Intent(VPN_STATUS_BROADCAST);
        intent.putExtra(VPN_STATUS_EXTRA, isConnected);
        sendBroadcast(intent); // Send broadcast to the Activity
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
