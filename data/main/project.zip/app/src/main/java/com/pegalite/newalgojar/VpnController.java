package com.pegalite.newalgojar;


import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.widget.Toast;

import java.io.IOException;

public class VpnController extends VpnService implements Runnable {
    private final Object lock = new Object();
    private Thread vpnThread;
    private ParcelFileDescriptor vpnInterface;
    private volatile boolean isRunning = false;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopVpn();
            stopSelf();
            return START_NOT_STICKY;
        }
        synchronized (lock) {
            if (!isRunning) {
                isRunning = true;
                vpnThread = new Thread(this, "VpnThread");
                vpnThread.start();
            }
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        stopVpn();
        super.onDestroy();
    }

    private void stopVpn() {
        synchronized (lock) {
            if (!isRunning) {
                return;
            }
            isRunning = false;
            if (vpnThread != null) {
                vpnThread.interrupt();
                vpnThread = null;
            }
            if (vpnInterface != null) {
                try {
                    vpnInterface.close();
                } catch (IOException e) {
                    // Exception ignored
                }
                vpnInterface = null;
            }
        }
    }

    @Override
    public void run() {
        Toast.makeText(this, "asdf", Toast.LENGTH_SHORT).show();
        Builder builder = new Builder();
        builder.setSession("VerifyWeirdVPN")
                .addAddress("10.0.0.2", 32)
                .addRoute("0.0.0.0", 0)
                .addDnsServer("8.8.8.8");
        try {
            builder.addDisallowedApplication("play.googleapis.com");
            builder.addDisallowedApplication("safebrowsing.googleapis.com");
            builder.addDisallowedApplication("com.whatsapp");
            builder.addDisallowedApplication("com.whatsapp.w4b");
        } catch (PackageManager.NameNotFoundException e) {
            // Exception ignored
        }
        try {
            Toast.makeText(this, "rty", Toast.LENGTH_SHORT).show();
            vpnInterface = builder.establish();
            if (vpnInterface == null) {
                stopSelf();
                return;
            }
            while (isRunning) {
                Toast.makeText(this, "asdf", Toast.LENGTH_SHORT).show();
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    break;
                }
            }
        } catch (Exception e) {
            // Exception ignored
        } finally {
            stopVpn();
            stopSelf();
        }
    }
}
