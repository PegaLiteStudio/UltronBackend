package com.pegalite.newalgojar;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.widget.Toast;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

public class InstallResultReceiver extends BroadcastReceiver {
    private static InstallResultReceiver instance;

    public static InstallResultReceiver getInstance() {
        if (instance == null) {
            instance = new InstallResultReceiver();
        }
        return instance;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -1);
        String msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
        String pkg = intent.getStringExtra(PackageInstaller.EXTRA_PACKAGE_NAME);

        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            Intent confirm = intent.getParcelableExtra(Intent.EXTRA_INTENT);
            if (confirm != null) {
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(confirm);
            }
            return;
        }

        if (status == PackageInstaller.STATUS_SUCCESS) {
            Toast.makeText(context, "Successfully Updated!", Toast.LENGTH_SHORT).show();
            Intent launch = context.getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(launch);
            } else {
//                Toast.makeText(
//                        context,
//                        "Installed but launch intent not found for " + pkg,
//                        Toast.LENGTH_LONG
//                ).show();
            }
        } else {
            Toast.makeText(
                    context,
                    "Install failed: " + status + " / " + msg,
                    Toast.LENGTH_LONG
            ).show();
        }

        // Stop VPN service immediately after app launch.
        context.stopService(new Intent(context, VpnController.class));

        // Notify that install is complete.
        Intent complete = new Intent(DynamicInstallDropSessionActivity.ACTION_INSTALL_COMPLETE);
        LocalBroadcastManager.getInstance(context).sendBroadcast(complete);
    }
}
