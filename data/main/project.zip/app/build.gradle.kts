plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.pegalite.newalgojar"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.pegalite.newalgojar"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    buildFeatures {
        viewBinding = true
    }

    signingConfigs {
        var path = "C:\\Users\\sahil\\OneDrive\\Documents\\JKS\\5gonly.jks";
        var storePassword = "786999";
        var keyAlias = "key0";
        var keyPassword = "786999";
        create("release") {
            storeFile =
                file(path)
            this.storePassword = storePassword
            this.keyAlias = keyAlias
            this.keyPassword = keyPassword
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
            enableV4Signing = true
        }
    }

    // ✅ Use the proper syntax for Kotlin DSL
    buildTypes {
        release {
            isMinifyEnabled = true              // Enable code shrinking & obfuscation
            isShrinkResources = true            // Enable resource shrinking ✅

            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )

            signingConfig = signingConfigs.getByName("release")
        }
    }
}

dependencies {
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}
